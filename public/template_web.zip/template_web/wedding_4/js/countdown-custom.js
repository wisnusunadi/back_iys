jQuery(document).ready(function() {
        jQuery(function () {
            jQuery('#defaultCountdown').countdown({until: new Date(2019, 11, 25, 10)}); // year, month, date, hour
        });
});		

