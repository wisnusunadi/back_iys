jQuery(document).ready(function () {
    jQuery(function () {
        jQuery('#defaultCountdown').countdown({ until: new Date(2024, 11, 25, 1) }); // year, month, date, hour
    });
});

